import os
import subprocess
import threading
from time import sleep
import time
import sys

CHARS_TO_PRINT = 100
TIMEOUT_TIME   = 60

#CONFIG_PATH = "configs/criteo_kaggle_19b_random.cfg"
CONFIG_PATH = "configs/criteo_kaggle.cfg"

libdir = os.path.join(os.getcwd(), 'local', 'lib')

def launch_ps(num_workers, num_task, ps_ip, ps_port, use_softmax):

    if use_softmax:
       command =  \
          './parameter_server_softmax configs/mnist_lambdas.cfg --nworkers {} --rank {} --ps_ip {}' \
          .format(num_workers, num_task)
    else:
       if ps_ip == "":
           command =  \
              './parameter_server --config {} --nworkers {} --rank {}' \
              .format(CONFIG_PATH, num_workers, num_task, ps_ip)
       else:
           command =  \
              './parameter_server --config {} --nworkers {} --rank {} --ps_ip {} --ps_port {}' \
              .format(CONFIG_PATH, num_workers, num_task, ps_ip, ps_port)

    print("Command: ", command)

    try:
      process = subprocess.Popen(command.split(), stdout=subprocess.PIPE)

      now = time.time()
      output = ""
      for c in iter(lambda: process.stdout.read(CHARS_TO_PRINT), ''):
          output = c
          for c in iter(lambda: process.stdout.read(1), ''):
              output += c
              if c == '\n':
                 print(output)
                 output = ""
                 break
          
      for c in iter(lambda: process.stdout.read(1), ''):
          output += c
      print(output)

      return ''.join(output)
    except:
      return ""


def cpu_benchmark():
    command =  './bin_worker'

    output = ""
    print("Command: ", command)
    process = subprocess.Popen(command.split(), stdout=subprocess.PIPE)

    now = time.time()
    for c in iter(lambda: process.stdout.read(CHARS_TO_PRINT), ''):
        diff = time.time() - now
        if diff > TIMEOUT_TIME:
            break
        output += c 
    print(output)

    return ''.join(output)

def iperf_benchmark():
    command =  './iperf3 -c 172.31.4.190 -t 5'

    output = ""
    print("Command: ", command)
    process = subprocess.Popen(command.split(), stdout=subprocess.PIPE)

    now = time.time()
    for c in iter(lambda: process.stdout.read(CHARS_TO_PRINT), ''):
        diff = time.time() - now
        if diff > TIMEOUT_TIME:
            break
        output += c 
    print(output)

    return ''.join(output)

def redis_benchmark():
    command =  './redis_benchmark_lambdas'

    output = ""
    print("Command: ", command)
    process = subprocess.Popen(command.split(), stdout=subprocess.PIPE)

    for c in iter(lambda: process.stdout.read(CHARS_TO_PRINT), ''):
        output += c 
    print(output)

    return ''.join(output)

def redis_benchmark_pubsub():
    command =  './redis_sender'

    output = ""
    print("Command: ", command)
    process = subprocess.Popen(command.split(), stdout=subprocess.PIPE)

    for c in iter(lambda: process.stdout.read(CHARS_TO_PRINT), ''):
        output += c 
    print(output)

    return ''.join(output)
    

def handler(event, context):
    results = []

    #redis_benchmark_pubsub()
    #return

    print("HELLO WORLD")
    print("event: ", event)
    num_task = event['num_task']
    num_workers = event['num_workers']
    ps_ip = ""
    ps_port = event['ps_port']
    if "ps_ip" in event:
        ps_ip = event['ps_ip']

    use_softmax = False

    print("num_task: ", num_task)
    print("num_workers: ", num_workers)
    print("use_softmax: ", use_softmax)
    results = launch_ps(num_workers, num_task, ps_ip, ps_port, use_softmax) # use_softmax: false for criteo, true for MNIST

    return []

#handler({"num_task":"2", "num_workers":"6"}, 0)

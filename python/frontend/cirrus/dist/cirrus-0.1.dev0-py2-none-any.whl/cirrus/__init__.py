name="cirrus"
from .cf import CollaborativeFiltering
from .lr import LogisticRegression
from .CostModel import CostModel
